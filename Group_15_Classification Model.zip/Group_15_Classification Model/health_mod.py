﻿import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

# Load your dataset
df = pd.read_csv('MaternalHealthRiskDataSet.csv')

# Assuming 'RiskLevel' is your target variable
X = df.drop('RiskLevel', axis=1)
y = df['RiskLevel']

# Remove any unwanted columns not present in the user input
user_columns = ['Age', 'SystolicBP', 'DiastolicBP', 'BS', 'HeartRate']
X = X[user_columns]

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the features without using feature names
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train your model (replace RandomForestClassifier with your model)
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Make predictions
def predict_risk():
    age = float(input("Enter Age: "))
    systolic_bp = float(input("Enter Systolic Blood Pressure: "))
    diastolic_bp = float(input("Enter Diastolic Blood Pressure: "))
    bs = float(input("Enter Blood Glucose Level: "))
    heart_rate = float(input("Enter Heart Rate: "))

    # Standardize user input without using feature names
    user_data = scaler.transform([[age, systolic_bp, diastolic_bp, bs, heart_rate]])

    # Make prediction
    prediction = model.predict(user_data)

    print(f"The predicted risk level is: {prediction[0]}")

# Call the function to make predictions
predict_risk()
